"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-15"
-------------------------------------------------------
"""
# Imports
from functions import intersection
# Constants

source1 = [10, 3, 10, 3, 1]
source2 = [1,10,2,3]
x = intersection([10, 3, 10, 3, 1], [8, 2, 7, 3, 6, 10, 32, 99])
print(x)