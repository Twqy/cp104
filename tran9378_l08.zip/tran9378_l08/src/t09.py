"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-15"
-------------------------------------------------------
"""
# Imports
from functions import many_search
# Constants

list = [94, 96, -22, -79, -28, 96, -50, 71, 24, -32]
search = 96
x = many_search(list,search)
print(x)