"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-02-17"
-------------------------------------------------------
"""
# Imports

# Constants

#t01
SQUARE_FEET_PER_ACRE = 43560
def footage_to_acres(square_feet): #done
    """
    -------------------------------------------------------
    Converts square footage to acres.
    Use: acres = footage_to_acres(square_feet)
    -------------------------------------------------------
    Parameters:
        square_feet - area in square feet (float >= 0)
    Returns:
        acres - square_footage in acres (float)
    ------------------------------------------------------
    """
    acres = square_feet/SQUARE_FEET_PER_ACRE
    return acres

#t02
def lawn_mowing(width, length, speed):
    """
    -------------------------------------------------------
    Determines how long it takes to mow a rectangular lawn.
    Use: time = lawn_mowing(width, length, speed)
    -------------------------------------------------------
    Parameters:
        width - width of a lawn in metres (float > 0)
        length - length of a lawn in metres (float > 0)
        speed - square metres cut per minute (float > 0)
    Returns:
        time_minutes - time required to mow the lawn (float)
    ------------------------------------------------------
    """
    time_minutes = (width * length)/speed
    return time_minutes

#t03
def date_extraction(date_number_format):
    """
    -------------------------------------------------------
    Extracts the year, month, and day from a date number in the format MMDDYYYY.
    Use: year, month, day = date_extraction(date_number_format)
    -------------------------------------------------------
    Parameters:
        date_number_format - a date number in the format MMDDYYYY (int > 0)
    Returns:
        year - year portion of date_number (int)
        month - month portion of date_number (int)
        day - day portion of date_number (int)
    ------------------------------------------------------
    """
    year = date_number_format % 10000
    month = (date_number_format//100) % year
    day = date_number_format%100
    return year

#t04
def fraction_multiplier(number1, denom1, number2, denom2):
    """
    -------------------------------------------------------
    Multiplies two fractions together and returns the results
    Use: num, denom, product = fraction_multiplier(number1, denom1, number2, denom2)
    -------------------------------------------------------
    Parameters:
        number1 - numerator of the first fraction (int)
        denom1 - denominator of the first fraction (int)
        number2 - numerator of the second fraction (int)
        denom2 - denominator of the second fraction (int)
    Returns:
        num - numerator of the resulting fraction (int)
        denom - denominator of the resulting fraction  (int)
        product - numerator divided by denominator (float)
    ------------------------------------------------------
    """
    num = number1 * number2
    den = denom1 * denom2
    product = num/den
    return num, den, product
    
from math import sqrt
GRAVITATION_ACCELERATION = float(9.8)
#t05
def falling_distance(time):
    """
    -------------------------------------------------------
    Calculates distance an object has fallen due to gravity given
    the time it is fallen.
    Use: distance = falling_distance(falling_time)
    -------------------------------------------------------
    Parameters:
        falling_time - time object has fallen in seconds (int >= 0)
    Returns:
        distance - distance object has fallen in metres (float)
    -------------------------------------------------------
    """
    d = time**2*GRAVITATION_ACCELERATION/2
    return d

