"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-05"
-------------------------------------------------------
"""
# Imports
from functions import generate_matrix_num
# Constants
rows = 3
cols = 4
low = -10
high = 10
value_type = 'int'

matrix = generate_matrix_num(rows, cols, low, high, value_type)
print(matrix)