"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-05"
-------------------------------------------------------
"""
# Imports
from functions import find_position
# Constants
matrix = [[-6, 5, 7], [3, -6, -2], [9, -8, -7], [0, -7, -6]]

x= find_position(matrix)
print(x)