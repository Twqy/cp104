"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-05"
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose
# Constants
matrix = [[6, 4, 24], [1, -9, 8]]

x= matrix_transpose(matrix)
print(x)
