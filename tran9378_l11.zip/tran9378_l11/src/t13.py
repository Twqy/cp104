"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-05"
-------------------------------------------------------
"""
# Imports
from functions import matrix_scalar_multiply
# Constants
matrix = [[-6,-3,-7],[-4,5,-13]]
num = 5

x= matrix_scalar_multiply(matrix, num)
print(x)