"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-05"
-------------------------------------------------------
"""
# Imports
from functions import generate_matrix_char
# Constants

rows = 3
cols = 4

x = generate_matrix_char(rows, cols)
print(x)