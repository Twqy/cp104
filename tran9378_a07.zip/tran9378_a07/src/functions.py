"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-23"
-------------------------------------------------------
"""
# Imports

# Constants

#t01
def list_of_factors(number):
    """
    -------------------------------------------------------
    Gets a list of factors from a user.
    list_of_factors takes an integer greater than 0 as a parameter
    list_of_factors takes an integer greater than 0 as a parameter (number) and returns a list of the factors that make up that number excepting the number itself. An integer's factors are the whole numbers that the integer can be evenly divided by.
    Use: number_list = list_of_factors()
    -------------------------------------------------------
    Returns:
        factors - A list of positive integers (list of int)
    ------------------------------------------------------
    """
    factors = []
    for i in range(1, number):
        if number % i == 0:
            factors.append(i)
    return factors
#t02
def list_of_positives():
    """
    -------------------------------------------------------
    Gets a list of positive numbers from a user.
    Negative numbers are ignored. Enter 0 to stop entries.
    Use: number_list = list_of_positives()
    -------------------------------------------------------
    Returns:
        number_list - A list of positive integers (list of int)
    ------------------------------------------------------
    """
    user = -1
    list = []
    while user !=0:
        user = int(input("Enter a number: "))
        if user >0:
            list.append(user)
        else:
            pass
    return list
#t03
def find_indexes(numbers, target_number):
    """
    -------------------------------------------------------
    Finds the indexes of target_number in numbers.
    Use: index_list = find_indexes(numbers, target_number)
    -------------------------------------------------------
    Parameters:
        numbers - list of values (list)
        target_number - value to look for in num_list (*)
    Returns:
        index_list - list of indexes of target_number (list of int)
    -------------------------------------------------------
    """
    index_list = []
    for i in range(0,len(numbers)):
        if numbers[i] == target_number:
            index_list.append(i)
    return index_list
#t04
def list_subtraction(minuend, subtrahend):
    """
    -------------------------------------------------------
    Alters the contents of minuend so that it does not contain
    any values in subtrahend.
    i.e. the values in the first list that appear in the second list
    are removed from the first list.
    Use: list_subtraction(minuend, subtrahend)
    -------------------------------------------------------
    Parameters:
        minuend - a list of values (list)
        subtrahend - a list of values to not include in difference (list)
    Returns:
        None
    ------------------------------------------------------
    """
    for i in subtrahend:
        if i in minuend:
            while i in minuend:
                minuend.remove(i)
    return None
#t05
def check_sorted(numbers):
    """
    -------------------------------------------------------
    Determines whether a list is sorted.
    Use: in_order, index = check_sorted(numbers)
    -------------------------------------------------------
    Parameters:
        numbers - a list of numbers (list)
    Returns:
        in_order - True if numbers is sorted, False otherwise (bool)
        index - index of first value not in order,
            -1 if in_order is True (int)
    ------------------------------------------------------
    """
    BOOLEAN = True
    if len(numbers) <= 1:
        BOOLEAN =  True, -1
    for i in range(len(numbers) - 1):
        if numbers[i] > numbers[i+1]:
            BOOLEAN =  False, i +1
    return BOOLEAN, -1