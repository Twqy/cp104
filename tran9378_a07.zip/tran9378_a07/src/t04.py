"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-23"
-------------------------------------------------------
"""
# Imports
from functions import list_subtraction
# Constants
minuend = [5,5,4,5]
subtrahend = [5]

x= list_subtraction(minuend, subtrahend)
print(x)