"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-23"
-------------------------------------------------------
"""
# Imports
from functions import find_indexes
# Constants
numbers =1,2,3,4,1,1
target_number = 1

x = find_indexes(numbers, target_number)
print(x)