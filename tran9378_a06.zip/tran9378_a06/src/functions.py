"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-16"
-------------------------------------------------------
"""
# Imports

# Constants
#t01
def winner():
    """
    -------------------------------------------------------
    Determines the count of a colour
    Use: winner = winner()
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        winner - True if number is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    BLUE = 0
    GREY = 0
    user = 'hi'
    while user != '':
        user = input("Enter the winning team: ")
        if user == 'blue':
            BLUE +=1
        if user == 'grey':
            GREY += 1
    return(BLUE,GREY)
    
#t02
def is_prime_number(number):
    """
    -------------------------------------------------------
    Determines if number is a prime number.
    Use: is_prime = is_prime_number(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        is_prime - True if number is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    is_prime = True
    if number <= 1:
        is_prime =  False
    elif number == 2:
        is_prime =  True
    elif number % 2 == 0:
        is_prime =  False
    else:
        i = 3
        while i <= int(number**0.5):
            if number % i == 0:
                is_prime = False
            i += 2
        is_prime = True
    return is_prime

#t03
def interest_data(principal_amount, interest_rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_data(principal_amount, interest_rate, payment)
    -------------------------------------------------------
    Parameters:
        principal_amount - original value of a loan (float > 0)
        interest_rate - yearly interest interest_rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    monthly_interest_rate = interest_rate / 100 / 12
    monthly_interest = principal_amount * monthly_interest_rate
    MONTH = 1
    remaining_principal = principal_amount
    
    print(f"{'Month':<8}{'Payment':<12}{'Interest':<15}{'Remaining Principal':<20}")
    while remaining_principal > 0:
        interest = remaining_principal * monthly_interest_rate
        actual_payment = min(payment, remaining_principal + interest)
        remaining_principal -= (actual_payment - interest)
        print(f"{MONTH:<8}${actual_payment:<12,.2f}${interest:<15,.2f}${remaining_principal:<20,.2f}")
        MONTH += 1
    return(MONTH,actual_payment,interest,remaining_principal)
    
#t04
def count_digits(number):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: digits = count_digits(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int)
    Returns:
        digits - the number of digits in number (int)
    ------------------------------------------------------
    """
    number = abs(number)
    DIGITS = 0
    while number > 0:
        number //= 10
        DIGITS += 1
    return DIGITS

#t05
def sum_of_factors(number):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = sum_of_factors(number)
    -------------------------------------------------------
    Parameters:
        number - a positive integer (int >= 1)
    Returns:
        total - the total of number's factors (int)
    ------------------------------------------------------
    """
    TOTAL = 0
    DIVISOR = 1
    if number < 1 or not isinstance(number, int):
        raise ValueError("Input must be a positive integer (int >= 1)")
    while DIVISOR < number:
        if number % DIVISOR == 0:
            TOTAL += DIVISOR
        DIVISOR += 1

    return TOTAL 
    