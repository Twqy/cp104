"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-29"
-------------------------------------------------------
"""
# Imports
from functions import customer_best
# Constants

filename = 'customers.txt'
fh = open(filename,'r',encoding='utf-8')
line = customer_best(fh)
print(line)
fh.close()