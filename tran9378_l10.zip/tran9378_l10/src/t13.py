"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-29"
-------------------------------------------------------
"""
# Imports
from functions import file_copy
# Constants

filename = "words.txt"
fh_1 = open(filename, 'r', encoding='utf-8')

filename2 = 'customers.txt'
fh_2 = open(filename2, 'w', encoding='utf-8')

file_copy(fh_1, fh_2)
fh_1.close()
fh_2.close()



