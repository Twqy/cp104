"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-29"
-------------------------------------------------------
"""
# Imports
from functions import find_longest
# Constants

filename = "words.txt"
fh = open(filename, 'r', encoding='utf-8')
print(find_longest(fh))
fh.close()



