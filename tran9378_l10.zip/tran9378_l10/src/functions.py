"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-29"
-------------------------------------------------------
"""
# Imports

# Constants

#t01
def customer_record(fh, n):
    """
    -------------------------------------------------------
    Find the n-th record in a comma-delimited sequential file.
    Records are numbered starting with 0.
    Use: result = customer_record(fh, n)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
        n - the number of the record to return (int > 0)
    Returns:
        result - a list of the fields of the n-th record if it exists,
            an empty list otherwise (list)
    -------------------------------------------------------
    """
    iteration = 0
    line = fh.readline()

    while line and iteration < n:
        iteration +=1 
        line = fh.readline()
    result = line.strip().split(',')
    
    if iteration < n:
        result = []
    return result

#t03
def customer_best(fh):
    """
    -------------------------------------------------------
    Find the customer with the largest balance.
    Assumes file is not empty.
    Use: result = customer_best(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        result - the record with the greatest balance (list)
    -------------------------------------------------------
    """
    greatest = str(10)
    line = fh.readline()
    balance = []
    
    for line in fh:
        line = line.replace('\n',',').split(',')
        balance.append(line[3])
        for i in balance:
            if i > greatest:
                greatest = i
            else:
                pass
    
    return greatest

#t06    
def number_stats(fh):
    """
    -------------------------------------------------------
    Returns statistics on the numbers in a file.
    Assumes file is not empty.
    Use: smallest, largest, total, average = number_stats(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        smallest - smallest number (int)
        largest - largest number (int)
        total - sum of all the numbers in the file (int)
        average - average of all the numbers (float)
    ------------------------------------------------------
    """
    sum = 0
    count = 0
    line = fh.readline()
    current_Low=int(line)
    current_High=int(line)
    
    while line != '':
        number = int(line)
        sum = int(line)+ sum 
        if number < current_Low:
            current_Low = number
        if number > current_High:
            Current_High = number
        line = fh.readline()
        count += 1
    average = sum/count
    
    return(current_Low, current_High, sum, average)
#t10
def count_frequency_word(fh, word):
    """
    -------------------------------------------------------
    Counts the number of appearances of word in fh.
    Case is significant - line in file must match word in case.
    Use: count = count_frequency_word(fh, word)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
        word - the word to search for it in fh (str)
    Returns:
        count - the number of appearance of word in fh (int)
    ------------------------------------------------------
    """
    count = 0
    line=fh.readline()
    while line != '':
        if str(line.strip()) == word:
            count += 1
        line=fh.readline()
    
    return count
#t11
def find_longest(fh):
    """
    -------------------------------------------------------
    Finds the last word with longest length in fh.
    Assumes file is not empty.
    Use: word = find_longest(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        word - the last word with the longest length in fh (str)
    ------------------------------------------------------
    """
    longest_word = 'stuff'
    
    line = fh.readline()
    
    for line in fh:
        words = line.strip().split()
        for word in words:
            if len(word) >= len(longest_word):
                longest_word = word
            
    return longest_word
        
#t12
def find_shortest(fh):
    """
    -------------------------------------------------------
    Finds the first word with shortest length in fh.
    Assumes file is not empty.
    Use: word = find_shortest(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        word - the first word with the shortest length in fh (str)
    ------------------------------------------------------
    """
    line = fh.readline()
    smallest_word = 'fortnite_sussy_amongus_jdsklfhsdhfske'
    
    for line in fh:
        words = line.strip().split()
        for word in words:
            if len(word) <= len(smallest_word):
                smallest_word = word
    return smallest_word
    
#t13
def file_copy(fh_1, fh_2):
    """
    -------------------------------------------------------
    Copies the contents of fh_1 to fh_2.
    Any contents of fh_2 are overwritten.
    Use: file_copy(fh_1, fh_2)
    -------------------------------------------------------
    Parameters:
        fh_1 - source file (file handle - already open for reading)
        fh_2 - target file (file handle - already open for writing)
    Returns:
        None
    ------------------------------------------------------
    """
    line = fh_1.readline()
    
    while line != '':
        fh_2.write(line)
        line = fh_1.readline()
    
    return None
        