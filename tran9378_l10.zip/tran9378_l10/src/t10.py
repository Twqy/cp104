"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-29"
-------------------------------------------------------
"""
# Imports
from functions import count_frequency_word
# Constants

filename = "words.txt"
fh = open(filename, 'r', encoding='utf-8')
print(count_frequency_word(fh, 'Exercise'))
fh.close()