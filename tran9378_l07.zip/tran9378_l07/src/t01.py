"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-07"
-------------------------------------------------------
"""
# Imports
from functions import hi_lo_game
# Constants

high = 10
x = hi_lo_game(high)
print(f"You guessed it correct in {x} tries!")

