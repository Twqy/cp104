"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-07"
-------------------------------------------------------
"""
# Imports
from random import randint
# Constants

#t01
def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
    number = randint(1,high)
    attempts = 0
    user = None

    while user != number:
        user = int(input("Guess: "))
        attempts = attempts+1
        if user >number:
            print("Too high")
        elif user <number:
            print("Too low")
        else:
            print("Error")
    return(attempts)

#t02
def power_of_two(target):
    POWER = 1
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    while POWER < target:
        POWER *= 2
    return POWER

#t04
def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """
    num = 1
    sum_of_squares = 0
    
    while True:
        sum_of_squares += num ** 2
    
        if sum_of_squares >= target:
            return sum_of_squares
        num += 1


#t08
def budget(available):
    """
    -------------------------------------------------------
    Asks a user for a series of expenses in a month. Calculate the
    total expenses and determines whether the user is in "Surplus",
    "Deficit", or "Balanced" status.
    Use: expenses, balance, status = budget(available)
    -------------------------------------------------------
    Parameters:
        available - money currently available (float >= 0)
    Returns:
        expenses - total monthly expenses (float)
        balance - remaining balance (float)
        status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            "Balanced" if user budget is balanced
    -----------------------------------------------------
    """
    expense = 1
    while expense != 0:
        expense = int(input("Enter an expense (0 to quit): "))
        expense += expense
    total = expense -1
    balance = available - total -1
    if balance > available:
        status = 'surplus'
    elif balance == available:
        status = 'balanced'
    else:
        status = 'deficit'
    return(total, balance, status)
    
    
    
    


#t10
def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """
    MAX_WORK_HOURS=40
    OVERTIME_RATE=1.5
    TAX_RATE = 3.625
    total =0
    num_employee=0
    id = int(input("Employee ID: "))
    hourly_pay = float(input("Hourly rate: "))
    hours_worked = float(input("Hours worked: "))

    while id != 0:
        if hours_worked >= MAX_WORK_HOURS:
            overtime_pay = (OVERTIME_RATE * hourly_pay)*\
                (hours_worked - MAX_WORK_HOURS)
            new_pay = (hourly_pay * hours_worked )
            total_pay = new_pay - (new_pay * TAX_RATE)
        else:
            total_pay = (hourly_pay * hours_worked) 
            (hourly_pay * hours_worked * TAX_RATE)
        print(f"Net payment for employee {id}: {total_pay:.2f}")
        id = int(input("Employee ID: "))
        if id != 0:
            hourly_pay = float(input("Hourly rate: "))
            hours_worked = float(input("Hours worked: "))
        total = total + total_pay
        num_employee = num_employee +1
        average = total/num_employee
    return(total, average)
        
    
    
    