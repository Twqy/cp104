"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports

# Constants

#t01
def factorial_calculator(number): #DONE
    """
    -------------------------------------------------------
    Calculates and returns the factorial of number.
    Use: product = factorial_calculator(number)
    -------------------------------------------------------
    Parameters:
        number - number to factorial (int > 0)
    Returns:
        product - number! (int)
    ------------------------------------------------------
    """
    if number< 0:
        product = "Error"
    elif number == 0:
        product = 1
    else:
        product = 1
        for i in range(1, number + 1):
            product *= i
        return product

#t02

def calories_burned(per_min, minutes):
    """
    -------------------------------------------------------
    Calculates and returns the calories burned per minute
    Use: calories_burned(per_min, minutes):
    -------------------------------------------------------
    Parameters:
        number - number to factorial (int > 0)
    Returns:
        None 
    ------------------------------------------------------
    """    
    calories = 0
    
    for i in range(0,minutes+1,5):
        calories = per_min * i
        print(f"{i}\t{calories:.1f}")
        
    return(None)



#t03
def arrow_down(rows):
    """
    -------------------------------------------------------
    creates an outline of an arrows using a forloop
    Use: arrow_down(rows):
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """
    for i in range(rows):
        if i == rows - 1:
            print('#' *(2 * rows - 1))
        else:
            print(' ' * i + '#'+ ' ' *(2 * (rows - i - 1)- 1) + '#')
    return None
    #t04
def multiplication_table(start_num, stop_num):
    for i in range(start_num, stop_num + 1):
        print(f"Multiplication table for {i}:")
        for j in range(1, 11):
            print(f"{i}  {j} | {i*j}")
        print("\n")

#t05
def range_total(start, increment, count): #DONE
    """
    -------------------------------------------------------
    Uses a for loop to sum values from start by increment.
    Use: total = range_total(start, increment, count)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """
    total = 0
    for i in range(count):
        total += start
        start += increment

    return(total)
        