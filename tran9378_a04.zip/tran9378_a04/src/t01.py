"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-02"
-------------------------------------------------------
"""
# Imports
from functions import day_of_the_week
# Constants

x= day_of_the_week(3)
print(x)

variable=0
if variable <6 and variable >1:
    print(variable)