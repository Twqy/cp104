"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-22"
-------------------------------------------------------
"""
# Imports

# Constants

#t03
def parse_code(product_code): #8/8
    """
    -------------------------------------------------------
    Parses a given product code. A product code has three parts:
        The first three letters describe the product category
        The next four digits are the product ID
        The remaining characters describe the product's qualifiers
    Use: pc, pi, pq = parse_code(product_code)
    -------------------------------------------------------
    Parameters:
        product_code - a valid product code (str)
    Returns:
        pc - the category part of product_code (str)
        pi - the id part of product_code (str)
        pq - the qualifier part of product_code (str)
    -------------------------------------------------------
    """
    pc = product_code[0:3]
    pi = product_code[3:7]
    pq = product_code[7:10]
    return(pc,pi,pq)
#t04
def validate_code(product_code): #11/13
    """
    -------------------------------------------------------
    Parses a given product code and prints whether the various parts are valid.
    A product code has three parts:
        The first three letters describe the product category and must
        all be in upper case.
        The next four digits are the product ID.
        The remaining characters describe the product's qualifiers,
        such as colour, size, etc. and always begins with an uppercase letter.
    Use: category, digits, qualifiers = validate_code(product_code)
    -------------------------------------------------------
    Parameters:
        product_code - a product code (str)
    Returns:
        category - True if three upper-case characters, False otherwise
        digits - True if four digits, False otherwise
        qualifiers - True if starts with 1 upper-case letter, False otherwise
    -------------------------------------------------------
    """
    category = False
    digits = False 
    qualifiers = False
    first = product_code[0:3]
    second = product_code[3:7]
    third = product_code[7:9]
    x = third[0:1]
    
    if first.isupper():
        category = True
    else:
        pass
    if second.isdigit():
        digits = True
    else: 
        pass
    if x.isupper():
        qualifiers = True
    else:
        pass
        
    return category,digits,qualifiers
    
#t05
def password_strength(password): #12/12 weird bug
    """
    -------------------------------------------------------
    Checks the strength of a given password. A password is
    strong if it contains at least eight characters, has a
    combination of upper-case and lower-case letters, and
    includes digits. Prints one or more of:
        not long enough - if password less than 8 characters
        no digits - if password has no digits
        no upper case - if password has no upper case letters
        no lower case - if password has no lower case letters
    Use: password_strength(password)
    -------------------------------------------------------
    Parameters:
        password - the password to be checked (str)
    Returns:
        None
    ------------------------------------------------------
    """
    length = 0
    digit = 0
    upper = 0
    lower = 0
    letter_count = 0
    
    for i in range(0, len(password)):
        letter_count +=1
        if (password[i].isdigit()):
            digit +=1
        elif (password[i].isupper()):
            upper +=1
        elif (password[i].islower()):
            lower +=1
        
    if letter_count < 8:
        length = print('not long enough')
    else:
        pass
        
    if digit <1:
        digit = print('no digits')
    else:
        pass
        
    if upper <1:
        upper = print('no upper case')
    else:
        pass
        
    if lower <1:
        print("no lower case")
    else: 
        pass
        
    return None

#t10
def text_analyze(txt): #8/9
    """
    -------------------------------------------------------
    Analyzes txt and returns the number of uppercase letters,
    lowercase letters, digits, and number of whitespaces in txt.
    Use: uppr, lowr, dgts, whtspc = text_analyze(txt)
    -------------------------------------------------------
    Parameters:
        txt - the text to be analyzed (str)
    Returns:
        uppr - number of uppercase letters in txt (int >= 0)
        lowr - number of lowercase letters in txt (int >= 0)
        dgts - number of digits in txt (int >= 0)
        whtspc - number of white spaces in the text (spaces, tabs, linefeeds) (int >= 0)
    ------------------------------------------------------
    """
    UPPR = 0
    LOWR = 0
    DGTS = 0
    WHTSPC = 0
    
    for i in txt:
        if txt.isupper():
            UPPR +=1
        else:
            pass
        if txt.islower():
            LOWR +=1
        else:
            pass
        if txt.isdigit():
            DGTS +=1
        else: 
            pass
        if i == ' ':
            WHTSPC +=1
        else: 
            pass
        
    return(UPPR,LOWR,DGTS,WHTSPC)

#t12 #7/8
def comma_period_replace(string):
    """
    -------------------------------------------------------
    Replaces all the commas with a period in s.
    Use: out = comma_period_replace(string)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        out - string with all commas replaced by a period (str)
    ------------------------------------------------------
    """
    
    for i in string:
        if i == ',':
            replace = string.replace(',','.')
    return replace
