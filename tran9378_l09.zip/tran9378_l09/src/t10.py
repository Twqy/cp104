"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-22"
-------------------------------------------------------
"""
# Imports
from functions import text_analyze
# Constants

x = text_analyze("Python uses whitespace indentation, rather than curly brackets or keywords, to delimit blocks.")
print(x)