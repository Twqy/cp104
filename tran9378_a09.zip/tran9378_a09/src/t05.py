"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-06"
-------------------------------------------------------
"""
# Imports
from functions import student_data
# Constants

filename = "students.txt"
fh = open(filename, "r", encoding="utf-8")
student_data(file_handle)
fh.close()