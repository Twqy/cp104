"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-06"
-------------------------------------------------------
"""
# Imports

# Constants

#t01
def file_header(file_handle, count):
    """
    -------------------------------------------------------
    Prints first count lines of file_handle. Line numbering starts at 0.
    If length of file is shorter than count, stops printing after
    last line of file.
    Use: file_header(file_handle, count)
    -------------------------------------------------------
    Parameters:
        file_handle - file to process (file handle - open for reading)
        count - number of lines to print (int > 0)
    Returns:
        None
    -------------------------------------------------------
    """
    line = file_handle.readline()
    counting = 0
    while counting < count and line:
        print(line.strip())
        counting += 1
        line = file_handle.readline()
    return 
#t02
def extract_integers(file_handle):
    """
    -------------------------------------------------------
    Extracts positive integers from a file into a list of integers.
    Numbers are comma-delimited. Non-numeric tokens are ignored.
    Use: number_list = extract_integers(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - file to process (file handle - open for reading)
    Returns:
        number_list - a list of integers from file_handle (list of int)
    -------------------------------------------------------
    """
    number_list = []
    line = file_handle.readline()
 
    for line in file_handle:
        numbers = line.strip().split(',')
        for num in numbers:
            integer = int(num)
            if integer >0:
                number_list.append(integer)
    return number_list
#t03
def text_stats(file_handle):
    """
    -------------------------------------------------------
    Evaluates the contents of a file by counting upper-case letters,
    lower-case letters, digits, white-spaces (including end-of-line
    characters), and remaining characters.
    Use: ucount, lcount, dcount, wcount, rcount = text_stats(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - file to process (file handle - open for reading)
    Returns:
        ucount - The number of upper-case letters in the file (int)
        lcount - The number of lower-case letters in the file (int)
        dcount - The number of digits in the file (int)
        wcount - The number of white-space characters in the file (int)
        rcount - The number of remaining characters in the file (int)
    -------------------------------------------------------
    """
    ucount= 0
    lcount=0
    dcount=0
    wcount=0
    rcount=0
    for line in file_handle:
        for char in line:
            if char.isupper():
                ucount += 1
            elif char.islower():
                lcount += 1
            elif char.isdigit():
                dcount += 1
            elif char.isspace():
                wcount += 1
            else:
                rcount += 1
    return ucount, lcount, dcount, wcount, rcount
#t04
def add_numbers(fh_read, fh_write):
    """
    -------------------------------------------------------
    Adds line numbers to a file. Contents of fh_write contain contents
    of fh_read where every line has line numbers added to the beginning
    of the line in the format [number]. Line numbering starts at 0.
    Put a single space after the line number.
    Use: add_numbers(fh_read, fh_write)
    -------------------------------------------------------
    Parameters:
        fh_read - file to read (file - open for reading)
        fh_write - file to write (file - open for writing)
    Returns:
        None
    -------------------------------------------------------
    """
    line_number =0
    for line in fh_read:
        numbered_line = f"[{line_number}] {line}"
        fh_write.write(numbered_line)
        line_number +=  1 
    return 
#t05
def student_data(file_handle):
    """
    -------------------------------------------------------
    Get information from a file of file_handle and grades.
    Use: l_id, h_id, avg = student_data(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - student information file in the format
            surname,forename,id,mark (file - open for reading)
    Returns:
        l_id - the id of the student with the lowest mark (str)
        h_id - the id of the student with the highest mark (str)
        avg - the average mark (float)
    -------------------------------------------------------
    """
    lowest_mark = float('inf')
    highest_mark = float('-inf')
    total_marks =0
    count_students =0
    l_id =''
    h_id =''
    for line in file_handle:
        parts = line.strip().split(',')
        surname, forename, student_id, mark = parts[0], parts[1], parts[2], float(parts[3])
        if mark < lowest_mark:
            lowest_mark = mark
            l_id = student_id
        if mark > highest_mark:
            highest_mark = mark
            h_id = student_id
        total_marks += mark
        count_students += 1
    avg = total_marks / count_students if count_students > 0 else 0
    return l_id, h_id, avg
        
    