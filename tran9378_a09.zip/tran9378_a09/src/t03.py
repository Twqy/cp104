"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-06"
-------------------------------------------------------
"""
# Imports
from functions import text_stats
# Constants

filename = "addresses.txt"
fh = open(filename, "r", encoding="utf-8")
result = text_stats(file_handle)
fh.close()