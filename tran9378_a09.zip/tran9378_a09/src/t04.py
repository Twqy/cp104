"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-04-06"
-------------------------------------------------------
"""
# Imports
from functions import add_numbers
# Constants
 
filename = "wilde.txt"
fh_read = open(filename, "r", encoding="utf-8")
fh_write = open(filename, "w", encoding="utf-8")
add_numbers(fh_read, fh_write)
fh_read.close()
fh_write.close()