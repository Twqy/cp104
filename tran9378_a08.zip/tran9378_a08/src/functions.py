"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports

# Constants

#t01
def insert_spaces(sentence):
    """
    -------------------------------------------------------
    Create a new sentence with added space between words. Words start
    with upper-case characters.
    Use: spaced = insert_spaces(sentence)
    -------------------------------------------------------
    Parameters:
        sentence - sentence that represents a sentence in which all the
            words are run together (no spaces), but the first character
            of each word is uppercase. sentence has at least one
            character (str)
    Returns:
        spaced - new sentence in which the words are separated
            by spaces and only the first word starts with
            an uppercase character (str)
    -------------------------------------------------------
    """
    new_sentence = ''
    
    for x in range(0,len(sentence)):
        if sentence[x].isupper()== True and x > 0:
            sentence[x].lower()
            new_sentence += ' '
        if x == 0:
            new_sentence += sentence[x]
        if x > 0:
            new_sentence += sentence[x].lower()
    return new_sentence

#t02
def string_pluralizer(string):
    """
    -------------------------------------------------------
    Pluralizes a string according to the rules:
        - if string ends with 's', 'sh', or 'ch', add 'es'
        - if string ends with 'y' but not 'ay' or 'oy', replace
            the 'y' with 'ies'
        - otherwise add 's'
    Use: pluralized = string_pluralizer(string)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        pluralized - a pluralized_string version of string (str)
    -------------------------------------------------------
    """
    line = string
    length = len(line)
    new_line = ''
    
    if line[length-2:length] == 'sh' or line[length-2:length] == 'ch' or line[length-2:length] == 'es':
        new_line = line[:length-2] + 'es'
        
    elif line[length-1:length] == 'y' and line[length-2: length] != 'ay' and line[length-2:length] != 'oy':
        new_line  = line[:length-1] + 'ies'
        
    elif line[length - 1:length] == 's':
        new_line= line[:length-1] + 'es'
        
    return new_line
    
#t03
def common_suffix(str1, str2):
    """
    -------------------------------------------------------
    Returns the longest common ending of two strings.
    Use: suffix = common_suffix(str1, str2)
    -------------------------------------------------------
    Parameters:
        str1 - first string for ending comparison (str)
        str2 - second string for ending comparison (str)
    Returns:
        suffix - the longest common ending of str1 and str2 (str)
    -------------------------------------------------------
    """
    len1 = len(str1)
    len2 = len(str2)
    loop = True
    result = '' 
    x = 0
    
    while loop == True:
        if str1[len1-x-1:len1-x]==str2[len2-x-1:len2-x]:
            result = result + str1[len1-x-1:len1-x]
        else:
            loop = False 
    result = result[::-1]
    
    return result

#t04
def check_isbn(isbn):
    """
    -------------------------------------------------------
    Determines if an ISBN string is valid. An ISBN string is valid if:
        - it consists of only digits and dashes ('-')
        - it contains 5 groups of digits separated by dashes
        - its first group of digits is either '978' or '979'
        - its final group of digits is a single digit
        - its entire length is 17 characters
    Use: is_valid = check_isbn(isbn)
    -------------------------------------------------------
    Parameters:
        isbn - a string (str)
    Returns:
        is_valid - True if isbn is valid, False otherwise (boolean)
    -------------------------------------------------------
    """
    x = 0
    check_single = 0
    count = 0
    result = False
    
    if isbn.startwith("-") == False or isbn.endswith("-") == False and isbn.find("--") and isbn.count("-")==4:
        count = count + 1
    if isbn[:2] == '978' or isbn[:2] == '979':
        count += 1
        
    while isbn[len(isbn)-x-1:len(isbn-x)] != '-':
        check_single += 1
        x += 1
    
    if len(isbn)==17:
        count +=1
    if check_single == 1:
        count += 1
    if count ==4:
        result = True 
    return result
#t05
def check_word_chain(words):
    """
    -------------------------------------------------------
    Determines if a list of strings is a word chain. A word chain
    is a list of words in which the last character of a word in
    the list is the same as the first character of the next word
    in the list.
    Use: word_chain = check_word_chain(words)
    -------------------------------------------------------
    Parameters:
        words - a of strings (list of str, len > 1)
    Returns:
        word_chain - True if words is a word chain,
            False otherwise (boolean)
    -------------------------------------------------------
    """
    result = False 
    count = 0
    
    while words[count+1].startswith(words[count][len(words[count])-1:len(words[count])]) == True:
        count = count + 1
        if count == len(words)-1:
            result = True 
            break 
    return result

        
    