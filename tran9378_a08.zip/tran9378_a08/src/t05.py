"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports
from functions import check_word_chain
# Constants

words = ['camel', 'leopard', 'dog', 'giraffe', 'elephant']
x= check_word_chain(words)

print(x)