"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Ryan Tran
ID:         169069378
Email:     tran9378@mylaurier.ca
__updated__ = "2024-03-30"
-------------------------------------------------------
"""
# Imports
from functions import common_suffix
# Constants
str1 = 'running'
str2 = 'jumping'
x = common_suffix(str1, str2)
print(x)